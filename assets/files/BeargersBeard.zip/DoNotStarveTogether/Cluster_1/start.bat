cd /D C:\Program Files (x86)\Steam\steamapps\common\Don't Starve Together\bin
start "Master" dontstarve_dedicated_server_nullrenderer -console -cluster Cluster_1 -shard Master
start "Caves" dontstarve_dedicated_server_nullrenderer -console -cluster Cluster_1 -shard Caves